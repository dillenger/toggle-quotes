# toggle-quotes
About this Add-on:

Adds a toolbar button, a twisty in the first quote and a shortcut key [Alt+Q] to collapse quotes.

Complete rewrite for Thunderbird 78 and 91, necessary after development of QuoteCollapse stopped.
Now provides basic collapsing of all quotes in a message, no other add-ons are needed.

The functionality that was previously provided by QuoteCollapse is now included in Quote Colors & Collapse.
Please install Quote Colors & Collapse if you want that functionality, don't use both at the same time.
